<?php $__env->startSection('title'); ?>
    صفحه اصلی مقالات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <style>
        .pagination{
            margin: 0 auto;
            font-family: vazir;
            font-size: 12px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container margin_10">
        <div class="row art_index_new">
            <?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                       target="_blank">
                        <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                        <span class="post_jdate"><?php echo e($n->jdate); ?></span>
                        <span class="post_writer"><?php echo e($n->writer); ?></span>
                        <span class="post_category">
                            <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                        </span>
                        <p class="title"><?php echo e($n->title); ?></p>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="container margin_10">
        <div class="row">
            <div class="col-xl-9 col-lg-9 col-md-8 col-sm-6 col-xs-12">
                <div class="row">
                    <?php $__currentLoopData = $article_box_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-6 art_index_box scale_50">
                            <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                               target="_blank">
                                <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                            </a>
                            <span class="post_category">
                            دسته:
                            <a href="">
                                <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                            </a>
                            </span>
                            <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                               target="_blank">
                                <p class="title"><?php echo e($n->title); ?></p>
                                <div class="post_content">
                                    <?php echo substr($n->seo_des,0,400); ?>
                                </div>
                                <p class="post_continue">
                                    <i class="icon arrow left"></i>
                                    ادامه مطلب
                                </p>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row" style="margin: auto;padding: 10px;">
                    <?php echo e($article_box_1->render()); ?>

                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-xs-12">
                <p class="side_lable">
                    دیگر مقالات:
                </p>
                <?php $__currentLoopData = $article_side_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="art_index_rand">
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                        </a>
                        <span class=""><?php echo e($n->jdate); ?></span>
                        <span class=""><?php echo e($n->writer); ?></span>
                        <span class="">
                            دسته:
                            <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                            </span>
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <p class="title"><?php echo e($n->title); ?></p>
                            <div class="post_content">
                                <?php echo substr($n->seo_des,0,400); ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p class="side_lable">
                    <i class="icon list ol"></i>
                    دسته بندی ها:
                </p>
                <div class="art_index_cat">
                    <ul>
                        <?php $__currentLoopData = $category_side; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('/articles/category').'/'. $c->id .'/'. $c->ename_url); ?>"><?php echo e($c->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <p class="side_lable">
                    <i class="icon eye"></i>
                    پربازدیدها:
                </p>
                <?php $__currentLoopData = $article_side_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="art_index_rand">
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                        </a>
                        <span class=""><?php echo e($n->jdate); ?></span>
                        <span class=""><?php echo e($n->writer); ?></span>
                        <span class="">
                            دسته:
                            <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                            </span>
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <p class="title"><?php echo e($n->title); ?></p>
                            <div class="post_content">
                                <?php echo substr($n->seo_des,0,400); ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.article', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\newsblog\resources\views/article/index.blade.php ENDPATH**/ ?>