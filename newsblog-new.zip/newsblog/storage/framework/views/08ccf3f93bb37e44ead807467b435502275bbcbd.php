<?php $__env->startSection('title'); ?>
    مقالات | <?php echo e($cat_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <style>
        .pagination{
            margin: 0 auto;
            font-family: vazir;
            font-size: 12px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(sizeof($new) == 4): ?>
        <div class="container margin_10">
            <div class="row art_index_new">
                <?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-xs-6">
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                            <span class="post_jdate"><?php echo e($n->jdate); ?></span>
                            <span class="post_writer"><?php echo e($n->writer); ?></span>
                            <span class="post_category">
                            <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                        </span>
                            <p class="title"><?php echo e($n->title); ?></p>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="container">
        <div class="row margin_10">
            <p style="margin: 0;text-align: right;padding: 10px;font-family: vazir;font-size: 15px;">
                جستجو:
                <?php echo e($cat_name); ?>

            </p>
        </div>
    </div>

    <div class="container">
        <div class="row margin_10">
            <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 right_art">
                <p class="side_lable">
                    دیگر مقالات:
                </p>
                <?php $__currentLoopData = $article_side_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="art_index_rand">
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                        </a>
                        <span class=""><?php echo e($n->jdate); ?></span>
                        <span class=""><?php echo e($n->writer); ?></span>
                        <span class="">
                            دسته:
                            <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                            </span>
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <p class="title"><?php echo e($n->title); ?></p>
                            <div class="post_content">
                                <?php echo substr($n->seo_des, 0, 400); ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p class="side_lable">
                    <i class="icon list ol"></i>
                    دسته بندی ها:
                </p>
                <div class="art_index_cat">
                    <ul>
                        <?php $__currentLoopData = $category_side; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('/articles/category').'/'. $c->id .'/'. $c->ename_url); ?>"><?php echo e($c->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <p class="side_lable">
                    <i class="icon eye"></i>
                    پربازدیدها:
                </p>
                <?php $__currentLoopData = $article_side_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="art_index_rand">
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                        </a>
                        <span class=""><?php echo e($n->jdate); ?></span>
                        <span class=""><?php echo e($n->writer); ?></span>
                        <span class="">
                            دسته:
                            <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                            </span>
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <p class="title"><?php echo e($n->title); ?></p>
                            <div class="post_content">
                                <?php echo substr($n->seo_des, 0, 400); ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12 article_search_box bg-white">
                <div class="row">
                    <?php if(sizeof($result) == 0): ?>
                        <p class="alert alert-warning text-center d-block w-100">
                            موردی یافت نشد
                        </p>
                    <?php endif; ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="art_filter_box">
                            <p class="title"><?php echo e($r->title); ?></p>
                            <a href="<?php echo e(url('/article/').'/'.$r->id.'/'.$r->title_url); ?>"
                               target="_blank">
                                <img src="<?php echo e(url('/').$r->avatar); ?>" alt="<?php echo e($r->title); ?>">
                            </a>
                            <span class="">
                                تاریخ انتشار:
                                <?php echo e($r->jdate); ?>

                            </span>
                            <span class="">
                                نویسنده:
                                <?php echo e($r->writer); ?>

                            </span>
                            <span class="">
                            دسته:

                            <a href="<?php echo e(url('/articles/category').'/'.\App\Category::where('id', $r->cat_id)->value('id') . '/'. \App\Category::where('id', $r->cat_id)->value('ename_url')); ?>">
                                <?= \App\Category::where('id', $r->cat_id)->value('name'); ?>
                            </a>
                            </span>
                            <div class="post_content">
                                <?php echo substr($r->seo_des,0,600); ?>
                            </div>
                            <a href="<?php echo e(url('/article/').'/'.$r->id.'/'.$r->title_url); ?>"
                               target="_blank">
                                <p class="post_continue btn btn-success">
                                    <i class="icon arrow left"></i>
                                    ادامه مطلب
                                </p>
                            </a>


                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row" style="margin: auto;padding: 10px;">
                    <?php echo e($result->render()); ?>

                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 right_art">

                <p class="side_lable">
                    <i class="icon eye"></i>
                    پیشنهادات:
                </p>
                <?php $__currentLoopData = $article_side_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="art_index_rand">
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                        </a>
                        <span class=""><?php echo e($n->jdate); ?></span>
                        <span class=""><?php echo e($n->writer); ?></span>
                        <span class="">
                            دسته:
                            <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                            </span>
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <p class="title"><?php echo e($n->title); ?></p>
                            <div class="post_content">
                                <?php echo substr($n->seo_des, 0, 400); ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p class="side_lable">
                    دیگر مقالات:
                </p>
                <?php $__currentLoopData = $article_side_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="art_index_rand">
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <img src="<?php echo e(url('/').$n->avatar); ?>" alt="<?php echo e($n->title); ?>">
                        </a>
                        <span class=""><?php echo e($n->jdate); ?></span>
                        <span class=""><?php echo e($n->writer); ?></span>
                        <span class="">
                            دسته:
                            <?= \App\Category::where('id', $n->cat_id)->value('name'); ?>
                            </span>
                        <a href="<?php echo e(url('/article/').'/'.$n->id.'/'.$n->title_url); ?>"
                           target="_blank">
                            <p class="title"><?php echo e($n->title); ?></p>
                            <div class="post_content">
                                <?php echo substr($n->seo_des, 0, 400); ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.article', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\newsblog\resources\views/article/article_filter.blade.php ENDPATH**/ ?>