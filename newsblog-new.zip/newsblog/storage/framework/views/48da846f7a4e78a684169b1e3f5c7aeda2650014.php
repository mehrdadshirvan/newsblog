<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row box_shadow bg-white bg-fff">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 padding_0" style="padding: 0">
               <table class="table table-hover table-striped" style="direction: rtl">
                   <tr>
                       <th>
                           ردیف
                       </th>
                       <th>
                           نویسنده
                       </th>
                       <th>
                           عنوان
                       </th>
                       <th>
                           تصویر
                       </th>
                       <th>
                           ویرایش
                       </th>
                       <th>
                           حذف
                       </th>
                   </tr>
                   <?php $i=1; ?>
                   <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="ar_<?php echo e($ar->id); ?>">
                        <td style="width: 15px"><?php echo e($i); ?></td>
                        <td><?php echo e($ar->writer); ?></td>
                        <td><?php echo e($ar->title); ?></td>
                        <td style="    width: 150px;"><img src="<?php echo e(url('/').$ar->avatar); ?>" style="    width: 150px;"></td>
                        <td style="width: 10px;">
                            <a href="<?php echo e(url('/admin/article/edit/').'/'.$ar->id); ?>" class="btn btn-info">
                                <i class="fa fa-pencil"></i>
                            </a>
                        </td>
                        <td style="width: 10px;">
                            <a href="#" onclick="delete_article(<?php echo e($ar->id); ?>);" class="btn btn-danger">
                                <i class="fa fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                       <?php $i++; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </table>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row margin_10" style="margin: 10px auto">
            <div style="margin: auto;direction: rtl;">
                <?php echo e($article->render()); ?>

            </div>
        </div>
    </div>

    <script>
        function delete_article(id){
            $.ajax({
                url: '<?php echo e(url('/admin/article/del')); ?>',
                data: "id=" + id + "&_token=" + "<?php echo e(csrf_token()); ?>",
                type: 'POST',
                success: function(data){
                    if(data == "ok"){
                        $("#ar_"+id).hide();
                    }else{
                       alert('error');
                    }
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\newsblog\resources\views/admin/article/show_all.blade.php ENDPATH**/ ?>