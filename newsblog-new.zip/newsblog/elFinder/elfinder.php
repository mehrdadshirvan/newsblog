<?php
die(header("location: https://piinstartup.ir/error/404"));
exit;
?>